const express = require('express');
const router = express.Router();
const pool = require('../db/config');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');

// All consumer routes require auth + consumer role
router.use(authMiddleware);
router.use(roleMiddleware(['consumer']));

// ── GET /api/consumer/connections ─────────────────────────────────────────────
router.get('/connections', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        uc.connection_id,
        uc.connection_status,
        uc.connection_date,
        u.utility_name,
        u.unit_of_measurement,
        LOWER(u.utility_name) AS utility_tag,
        t.tariff_name,
        t.billing_method,
        a.house_num,
        a.street_name,
        r.region_name,
        -- Latest meter reading units
        COALESCE((
          SELECT mr.units_logged
          FROM meter_reading mr
          JOIN meter m ON mr.meter_id = m.meter_id
          WHERE m.meter_id = uc.meter_id
          ORDER BY mr.time_to DESC
          LIMIT 1
        ), 0) AS units_used
      FROM utility_connection uc
      JOIN utility u ON uc.utility_id = u.utility_id
      JOIN tariff t ON uc.tariff_id = t.tariff_id
      JOIN address a ON uc.address_id = a.address_id
      JOIN region r ON a.region_id = r.region_id
      WHERE uc.consumer_id = $1
      ORDER BY uc.connection_date DESC
    `, [req.user.userId]);

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch connections' });
  }
});

// ── GET /api/consumer/bills ───────────────────────────────────────────────────
router.get('/bills', async (req, res) => {
  const limit = parseInt(req.query.limit) || 20;
  try {
    const result = await pool.query(`
      SELECT
        bd.bill_document_id,
        bd.bill_type,
        bd.bill_period_start,
        bd.bill_period_end,
        bd.bill_generation_date,
        bd.unit_consumed,
        bd.energy_amount,
        bd.total_amount               AS amount,
        bp.bill_status                AS status,
        bp.due_date,
        bp.remarks,
        u.utility_name,
        LOWER(u.utility_name)         AS utility_tag,
        TO_CHAR(bd.bill_period_start, 'Mon YYYY') AS period,
        uc.connection_id
      FROM bill_document bd
      JOIN utility_connection uc ON bd.connection_id = uc.connection_id
      JOIN utility u ON uc.utility_id = u.utility_id
      LEFT JOIN bill_postpaid bp ON bd.bill_document_id = bp.bill_document_id
      WHERE uc.consumer_id = $1
      ORDER BY bd.bill_generation_date DESC
      LIMIT $2
    `, [req.user.userId, limit]);

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch bills' });
  }
});

// ── GET /api/consumer/bills/:id ───────────────────────────────────────────────
router.get('/bills/:id', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        bd.*,
        bp.bill_status AS status,
        bp.due_date,
        bp.remarks,
        u.utility_name,
        LOWER(u.utility_name) AS utility_tag,
        u.unit_of_measurement,
        t.tariff_name,
        t.billing_method
      FROM bill_document bd
      JOIN utility_connection uc ON bd.connection_id = uc.connection_id
      JOIN utility u ON uc.utility_id = u.utility_id
      JOIN tariff t ON uc.tariff_id = t.tariff_id
      LEFT JOIN bill_postpaid bp ON bd.bill_document_id = bp.bill_document_id
      WHERE bd.bill_document_id = $1 AND uc.consumer_id = $2
    `, [req.params.id, req.user.userId]);

    if (result.rows.length === 0) return res.status(404).json({ error: 'Bill not found' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch bill' });
  }
});

// ── GET /api/consumer/usage ───────────────────────────────────────────────────
router.get('/usage', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        mr.reading_id,
        mr.units_logged,
        mr.time_from,
        mr.time_to,
        u2.utility_name,
        LOWER(u2.utility_name) AS utility_tag,
        u2.unit_of_measurement
      FROM meter_reading mr
      JOIN meter m ON mr.meter_id = m.meter_id
      JOIN utility_connection uc ON m.meter_id = uc.meter_id
      JOIN utility u2 ON uc.utility_id = u2.utility_id
      WHERE uc.consumer_id = $1
      ORDER BY mr.time_to DESC
      LIMIT 30
    `, [req.user.userId]);

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch usage' });
  }
});

// ── GET /api/consumer/complaints ──────────────────────────────────────────────
router.get('/complaints', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        c.complaint_id,
        c.description,
        c.status,
        c.complaint_date,
        c.assignment_date,
        c.resolution_date,
        c.remarks,
        u.utility_name,
        LOWER(u.utility_name) AS utility_tag
      FROM complaint c
      LEFT JOIN utility_connection uc ON c.connection_id = uc.connection_id
      LEFT JOIN utility u ON uc.utility_id = u.utility_id
      WHERE c.consumer_id = $1
      ORDER BY c.complaint_date DESC
    `, [req.user.userId]);

    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch complaints' });
  }
});

// ── POST /api/consumer/complaints ─────────────────────────────────────────────
router.post('/complaints', async (req, res) => {
  const { connection_id, description } = req.body;
  if (!description) return res.status(400).json({ error: 'Description is required' });

  try {
    const result = await pool.query(`
      INSERT INTO complaint (consumer_id, connection_id, description, status, complaint_date)
      VALUES ($1, $2, $3, 'Pending', CURRENT_DATE)
      RETURNING *
    `, [req.user.userId, connection_id || null, description]);

    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to submit complaint' });
  }
});

module.exports = router;


// ── POST /api/consumer/payments ───────────────────────────────────────────────
router.post('/payments', async (req, res) => {
  const { bill_document_id, payment_amount, payment_method, provider_name, phone_num, account_num } = req.body;

  if (!bill_document_id || !payment_amount || !payment_method) {
    return res.status(400).json({ error: 'bill_document_id, payment_amount, and payment_method are required' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Verify the bill belongs to this consumer and is payable
    const billCheck = await client.query(`
      SELECT bd.bill_document_id, bp.bill_status, uc.consumer_id
      FROM bill_document bd
      JOIN utility_connection uc ON bd.connection_id = uc.connection_id
      LEFT JOIN bill_postpaid bp ON bd.bill_document_id = bp.bill_document_id
      WHERE bd.bill_document_id = $1 AND uc.consumer_id = $2
    `, [bill_document_id, req.user.userId]);

    if (billCheck.rows.length === 0) return res.status(404).json({ error: 'Bill not found' });
    if (billCheck.rows[0].bill_status === 'Paid') return res.status(400).json({ error: 'Bill already paid' });

    // Insert payment method
    const methodRes = await client.query(
      `INSERT INTO payment_method (method_name) VALUES ($1) RETURNING method_id`,
      [payment_method]
    );
    const methodId = methodRes.rows[0].method_id;

    // Insert sub-type (mobile banking or bank)
    if (payment_method === 'mobile_banking') {
      await client.query(
        `INSERT INTO mobile_banking (method_id, provider_name, phone_num) VALUES ($1, $2, $3)`,
        [methodId, provider_name || 'bKash', phone_num]
      );
    } else if (payment_method === 'bank') {
      await client.query(
        `INSERT INTO bank (method_id, bank_name, account_num) VALUES ($1, $2, $3)`,
        [methodId, provider_name || 'Unknown', account_num || phone_num]
      );
    }

    // Insert payment record
    const paymentRes = await client.query(`
      INSERT INTO payment (bill_document_id, method_id, payment_amount, payment_date, status)
      VALUES ($1, $2, $3, CURRENT_DATE, 'Completed')
      RETURNING payment_id
    `, [bill_document_id, methodId, payment_amount]);

    // Mark bill as paid
    await client.query(
      `UPDATE bill_postpaid SET bill_status = 'Paid' WHERE bill_document_id = $1`,
      [bill_document_id]
    );

    await client.query('COMMIT');

    res.status(201).json({
      message: 'Payment successful',
      payment_id: paymentRes.rows[0].payment_id,
    });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Payment failed' });
  } finally {
    client.release();
  }
});